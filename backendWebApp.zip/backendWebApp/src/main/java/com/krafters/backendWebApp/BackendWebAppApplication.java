package com.krafters.backendWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendWebAppApplication.class, args);
	}

}
