package com.krafters.backendWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
